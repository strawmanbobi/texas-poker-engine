#! /usr/bin/env python
# -*- coding:utf-8 -*-

import json
import hashlib
from websocket import create_connection
# pip install websocket-client

ws = ""

def takeAction(action, data):
    if action == "__bet":
        ws.send(json.dumps({
            "eventName": "__action",
            "data": {
                "action": "bet",
                "playerName": "<Your Name>",
                "amount": 100
            }
        }))
    elif action == "__action":
        ws.send(json.dumps({
            "eventName": "__action",
            "data": {
                "action": "call",
                "playerName": "<Your Name>"
            }
        }))
    else:
        pass


def doListen():
    try:
        global ws
        hasn_md5 = hashlib.md5()
        hasn_md5.update('<Your Password>')
        password_md5 = hasn_md5.hexdigest()

        ws = create_connection("ws://ai.cad-stg.trendmicro.com:<Copy From Website>")

        # Join Game
        ws.send(json.dumps({
            "eventName": "__join",
            "data": {
                "playerName": "<Your Name>",
                "phoneNumber": "<Your PhoneNum>",
                "password": password_md5,
                "ticket": "<Copy From Website>",
                "port": '<Copy From Website>',
                "isHuman": 0,
                "danmu": 0,
                "gameName": "texas_holdem"
            }
        }))

        # wait for msg and take action
        while True:
            result = ws.recv()
            msg = json.loads(result)
            event_name = msg["eventName"]
            data = msg["data"]
            print event_name
            print data
            takeAction(event_name, data)
    except Exception, e:
        print e.message
        doListen()


if __name__ == '__main__':
    doListen()
