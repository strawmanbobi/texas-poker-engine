class Winner():
    def __init__(self, playerName, hand, chips):
        self.playerName = playerName
        self.hand = hand
        self.chips = chips
