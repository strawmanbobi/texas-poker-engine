from Data import Data

class ActionData(Data):
    def __init__(self, action, amount):
        self.action = action
        self.amount = amount
