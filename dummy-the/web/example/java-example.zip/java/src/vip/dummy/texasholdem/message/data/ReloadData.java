package vip.dummy.texasholdem.message.data;

public class ReloadData {

    public ReloadData() {

    }
}
