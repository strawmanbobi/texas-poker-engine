package vip.dummy.texasholdem.indication;

public class Indication {

    private String eventName;

    public Indication(String eventName) {
        this.eventName = eventName;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }
}
